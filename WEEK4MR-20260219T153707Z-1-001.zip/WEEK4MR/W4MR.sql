create database airnbproject;
use airnbproject;
show tables;
select * from dim_customer;
select * from dim_date;
select * from dim_host;
select * from dim_property;
select * from fact_bookings;

-- Task 1: Host Success – Superhosts & Total Bookings


SELECT 
    h.Host_Name AS Host_Name,
    h.Superhost_Flag AS Superhost_Status,
    COUNT(f.Booking_ID) AS Total_Bookings,
    SUM(f.Revenue) AS Total_Revenue
FROM Fact_Bookings f
JOIN Dim_Host h 
    ON f.Host_ID = h.Host_ID
GROUP BY h.Host_Name, h.Superhost_Flag
ORDER BY Total_Bookings DESC;



-- Task 2: Property Revenue – Revenue by Property Type


SELECT 
    p.Property_Type AS Property_Type,
    COUNT(f.Booking_ID) AS Total_Bookings,
    SUM(f.Revenue) AS Total_Revenue,
    ROUND(AVG(f.Revenue),2) AS Avg_Revenue
FROM Fact_Bookings f
JOIN Dim_Property p
    ON f.Property_ID = p.Property_ID
GROUP BY p.Property_Type
ORDER BY Total_Revenue DESC;



-- Task 3: Guest Demographics – Average Booking Price by Age Group


SELECT 
    c.Age_Group AS Age_Group,
    COUNT(f.Booking_ID) AS Total_Bookings,
    ROUND(AVG(f.Revenue),2) AS Avg_Booking_Revenue
FROM Fact_Bookings f
JOIN Dim_Customer c
    ON f.Customer_ID = c.Customer_ID
GROUP BY c.Age_Group
ORDER BY Avg_Booking_Revenue DESC;



-- Task 4: Booking Origins – Total Bookings by Nationality


SELECT 
    c.Nationality AS Nationality,
    COUNT(f.Booking_ID) AS Total_Bookings,
    SUM(f.Revenue) AS Total_Revenue
FROM Fact_Bookings f
JOIN Dim_Customer c
    ON f.Customer_ID = c.Customer_ID
GROUP BY c.Nationality
ORDER BY Total_Bookings DESC;



-- Task 5: Rating Analysis – High Performing Properties
-- (Since no Rating column exists, using Revenue as performance indicator)


SELECT 
    p.Property_ID,
    p.Property_Type,
    ROUND(AVG(f.Revenue),2) AS Avg_Revenue
FROM Fact_Bookings f
JOIN Dim_Property p
    ON f.Property_ID = p.Property_ID
GROUP BY p.Property_ID, p.Property_Type
HAVING AVG(f.Revenue) > 1000
ORDER BY Avg_Revenue DESC;


